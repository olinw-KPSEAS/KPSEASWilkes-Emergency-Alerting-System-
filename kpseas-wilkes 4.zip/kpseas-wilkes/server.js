/**
 * KPSEAS Wilkes Emergency Alerting System
 * Network-ready server
 *
 * Run:  npm install && npm start
 * Then open http://<this-computer-ip>:3000 on any device on the network
 */

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const os = require('os');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

const PORT = process.env.PORT || 3000;
const ADMIN_PIN = '1111';

// Serve static files
app.use(express.static(path.join(__dirname)));

// Simple health check
app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    connectedReceivers: getReceiverCount(),
    time: new Date().toISOString()
  });
});

// Track connected clients
const clients = new Map(); // socketId -> { role, connectedAt }

function getReceiverCount() {
  let count = 0;
  for (const c of clients.values()) {
    if (c.role === 'teacher' || c.role === 'student' || c.role === 'receiver') count++;
  }
  return count;
}

io.on('connection', (socket) => {
  console.log(`[+] Client connected: ${socket.id}`);

  // Client registers its role
  socket.on('register', (data) => {
    const role = data?.role || 'receiver';
    clients.set(socket.id, { role, connectedAt: Date.now() });
    console.log(`    Registered as: ${role}`);

    // Tell everyone the current receiver count
    io.emit('status', {
      connectedReceivers: getReceiverCount(),
      time: Date.now()
    });
  });

  // Admin sends an alert
  socket.on('send-alert', (payload) => {
    // Basic PIN check on server side too
    if (payload.pin !== ADMIN_PIN) {
      socket.emit('error', { message: 'Invalid PIN' });
      return;
    }

    const alert = {
      eventCode: payload.eventCode,
      eventName: payload.eventName,
      voice: payload.voice || 'paul',
      note: payload.note || '',
      audioPath: payload.audioPath,
      timestamp: Date.now(),
      from: 'Front Office'
    };

    console.log(`\n🚨 ALERT SENT: ${alert.eventName} (${alert.eventCode})  voice=${alert.voice}`);

    // Broadcast to ALL connected clients (receivers will act on it)
    io.emit('alert', alert);

    // Confirm back to sender
    socket.emit('alert-sent', { success: true, alert });
  });

  socket.on('disconnect', () => {
    clients.delete(socket.id);
    console.log(`[-] Client disconnected: ${socket.id}`);
    io.emit('status', {
      connectedReceivers: getReceiverCount(),
      time: Date.now()
    });
  });
});

// Helper: print local network IPs so user knows what to open
function getLocalIPs() {
  const interfaces = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        ips.push(iface.address);
      }
    }
  }
  return ips;
}

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n========================================');
  console.log('  KPSEAS Wilkes Emergency Alerting System');
  console.log('========================================');
  console.log(`  Local:   http://localhost:${PORT}`);
  const ips = getLocalIPs();
  if (ips.length) {
    console.log('  Network (open these on other devices):');
    ips.forEach(ip => console.log(`           http://${ip}:${PORT}`));
  }
  console.log('========================================\n');
  console.log('Admin PIN: 1111');
  console.log('Waiting for connections...\n');
});
