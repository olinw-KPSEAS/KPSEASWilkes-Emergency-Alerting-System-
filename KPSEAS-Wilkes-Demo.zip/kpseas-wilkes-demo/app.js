// KPSEAS demo console. This app is a local UI simulator only.
// Do not connect this front end directly to school networks or life-safety equipment.

const DEMO_PIN = "1111"; // Demonstration only; never use a client-side PIN in production.

const announcements = {
  "Tornado Warning": {
    message: "Attention. The National Weather Service has issued a Tornado Warning for the area. Move immediately to your designated interior shelter area, stay away from windows, and follow staff instructions."
  },
  "Severe Thunderstorm Warning": {
    message: "Attention. A Severe Thunderstorm Warning is in effect for the area. Move indoors, stay away from windows, and follow staff instructions."
  },
  "Flash Flood Warning": {
    message: "Attention. A Flash Flood Warning is in effect. Stay inside designated safe areas and do not walk or drive through floodwater."
  },
  "Flood Warning": {
    message: "Attention. A Flood Warning is in effect for the area. Follow staff directions and remain away from flooded areas."
  },
  "Winter Storm Warning": {
    message: "Attention. A Winter Storm Warning has been issued. Remain indoors and follow school administration instructions."
  },
  "Ice Storm Warning": {
    message: "Attention. An Ice Storm Warning has been issued. Stay indoors and use caution around doors, walkways, and parking areas."
  },
  "Hurricane Warning": {
    message: "Attention. A Hurricane Warning is in effect. Follow the school's emergency procedures and all instructions from staff."
  },
  "Tropical Storm Warning": {
    message: "Attention. A Tropical Storm Warning is in effect. Remain in the designated safe area and follow staff instructions."
  },
  "Extreme Heat Warning": {
    message: "Attention. An Extreme Heat Warning is in effect. Stay in cooled indoor areas and follow staff directions."
  },
  "High Wind Warning": {
    message: "Attention. A High Wind Warning is in effect. Stay indoors and away from exterior windows."
  },
  "Fire Emergency": {
    message: "Attention. A fire emergency has been reported. Follow the posted evacuation route and staff instructions. Do not use elevators."
  },
  "Shelter in Place": {
    message: "Attention. Shelter in place. Move to your designated safe location, remain quiet, and wait for further instructions."
  },
  "Secure Campus": {
    message: "Attention. Secure campus procedures are now in effect. Follow staff instructions and remain inside the building."
  },
  "Evacuation": {
    message: "Attention. Evacuate using the route directed by staff. Walk calmly, leave belongings behind, and proceed to your designated assembly area."
  },
  "All Clear": {
    message: "Attention. The emergency has ended. An all clear has been issued. Resume activities only as directed by school staff."
  }
};

const loginPanel = document.querySelector("#loginPanel");
const consolePanel = document.querySelector("#console");
const loginForm = document.querySelector("#loginForm");
const loginError = document.querySelector("#loginError");
const alertForm = document.querySelector("#alertForm");
const previewPanel = document.querySelector("#previewPanel");
const eventLog = document.querySelector("#eventLog");
const emptyLog = document.querySelector("#emptyLog");
const audioPlayer = document.querySelector("#audioPlayer");
const audioNote = document.querySelector("#audioNote");

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const entered = document.querySelector("#pin").value;
  if (entered !== DEMO_PIN) {
    loginError.textContent = "Incorrect demonstration PIN.";
    return;
  }
  loginError.textContent = "";
  loginPanel.hidden = true;
  consolePanel.hidden = false;
});

alertForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const type = document.querySelector("#alertType").value;
  if (!type || !announcements[type]) return;

  const voice = document.querySelector("#voice").value;
  const audience = document.querySelector("#audience").value;
  const tones = document.querySelector("#headerTones").checked;
  document.querySelector("#previewTitle").textContent = type;
  document.querySelector("#previewVoice").textContent = voice;
  document.querySelector("#previewAudience").textContent = audience;
  document.querySelector("#previewTones").textContent = tones ? "Selected (not played)" : "Not selected";
  document.querySelector("#previewMessage").textContent = announcements[type].message;
  previewPanel.hidden = false;

  // Optional user-supplied recording. Files are not included in this starter project.
  const safeType = type.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const safeVoice = voice.toLowerCase().replace(/[^a-z0-9]+/g, "-");
  const audioPath = `assets/audio/${safeType}-${safeVoice}.mp3`;
  audioPlayer.pause();
  audioPlayer.removeAttribute("src");
  audioPlayer.load();
  audioPlayer.hidden = true;
  audioNote.textContent = `Optional recording path: ${audioPath}. Add a recording you are authorized to use.`;
  audioPlayer.onerror = () => {
    audioPlayer.hidden = true;
    audioNote.textContent = `No recording found at ${audioPath}. The text preview is available.`;
  };
  audioPlayer.oncanplay = () => {
    audioPlayer.hidden = false;
    audioNote.textContent = "User-supplied recording loaded. Press play to listen.";
  };
  audioPlayer.src = audioPath;
  audioPlayer.load();

  const item = document.createElement("li");
  const time = document.createElement("time");
  time.textContent = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
  const detail = document.createElement("span");
  detail.textContent = `${type} • ${voice} • ${audience} • preview only`;
  item.append(time, detail);
  eventLog.prepend(item);
  emptyLog.hidden = true;
});

document.querySelector("#resetButton").addEventListener("click", () => {
  alertForm.reset();
  previewPanel.hidden = true;
  audioPlayer.pause();
  audioPlayer.hidden = true;
  audioPlayer.removeAttribute("src");
  audioNote.textContent = "";
});

document.querySelector("#clearLog").addEventListener("click", () => {
  eventLog.replaceChildren();
  emptyLog.hidden = false;
});

document.querySelector("#logoutButton").addEventListener("click", () => {
  consolePanel.hidden = true;
  loginPanel.hidden = false;
  document.querySelector("#pin").value = "";
  previewPanel.hidden = true;
});
