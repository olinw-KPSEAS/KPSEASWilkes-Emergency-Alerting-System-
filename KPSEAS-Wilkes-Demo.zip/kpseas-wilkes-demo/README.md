# KPSEAS — Wilkes Emergency Alerting System (Demo)

A static, GitHub Pages-ready front-end prototype for a school emergency alert console.

## Run locally
1. Download and unzip the project.
2. Open `index.html` in a modern browser.
3. Sign in with demo PIN `1111`.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, `app.js`, and the `assets` folder.
3. In the repository, open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.

## Optional prerecorded audio
Place recordings you are authorized to use in `assets/audio/` using these filenames:

- `tornado-warning-crs-tom.mp3`
- `tornado-warning-paul.mp3`
- `severe-thunderstorm-warning-crs-tom.mp3`
- etc.

The filename pattern is:
`<alert-name-lowercase-with-hyphens>-<voice-lowercase-with-hyphens>.mp3`

The app displays a text preview even if no recording exists. It does not create synthetic speech.

## Important limitations
- This is a **simulation only**. It does not send alerts or connect to PA systems, computers, beacon lights, EAS/SAME encoders, NWS feeds, or school networks.
- The EAS header-tone checkbox is metadata only. No SAME/EAS header or EOM audio is generated or played.
- Recipient counts are sample values, not real device registrations.
- The PIN is hardcoded in browser JavaScript for demonstration. Anyone can inspect it. Do not use this for real authentication.
- Do not use this prototype as a life-safety system. A real deployment needs an authorized server-side design, secure identity and role management, audit logging, fail-safe behavior, accessibility review, and approved integrations developed with the school/district and relevant emergency-management authorities.
